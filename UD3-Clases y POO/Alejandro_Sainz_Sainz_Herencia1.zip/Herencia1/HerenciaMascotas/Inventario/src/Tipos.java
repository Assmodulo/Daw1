public enum Tipos {
    PERRO, GATO, LORO, CANARIO;
}
